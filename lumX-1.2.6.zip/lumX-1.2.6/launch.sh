#!/bin/sh

python $APPENGINE/dev_appserver.py --host 0.0.0.0 --port 8888 build/
