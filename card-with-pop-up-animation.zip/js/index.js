$(document).ready(function() {
  $(".card").click(function() {
    $(this).toggleClass("active");
  });
});